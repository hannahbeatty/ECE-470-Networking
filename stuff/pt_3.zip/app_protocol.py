
# app_protocol.py

import csmessage
from csmessage import REQS
import cspdu

class SmartHomeProtocol:
    """
    A high-level 'Application Protocol' class that encapsulates
    sending and receiving messages for login, logout, device control,
    and device queries. It uses CSmessage + REQS codes to communicate
    with the SmartHomeServer over a socket.
    """
    def __init__(self, socket_conn):
        """
        Create a SmartHomeProtocol with an established socket connection.
        :param socket_conn: A socket connected to the Smart Home Server.
        """
        self.pdu = cspdu.CSpdu(socket_conn)
        self.logged_in = False  # Track login state

    def send_login(self, username, password):
        """
        Send a LGIN request (login) to the server, then receive/handle response.
        Prints "Login successful!" or "Login failed!" accordingly.
        """
        msg = csmessage.CSmessage()
        msg.setType(REQS.LGIN)
        msg.addValue("username", username)
        msg.addValue("password", password)
        self.pdu.sendMessage(msg)

        response = self.receive_response()
        if response is not None:
            # Check server's response
            if response.getType() == REQS.LGIN and response.getValue("status") == "success":
                self.logged_in = True
                print("Login successful!")
            else:
                print("Login failed!")

    def send_logout(self):
        """
        Send a LOUT request (logout) to the server, then receive/handle response.
        Requires that you're already logged in.
        """
        if not self.logged_in:
            raise PermissionError("Must be logged in to log out.")

        msg = csmessage.CSmessage()
        msg.setType(REQS.LOUT)
        self.pdu.sendMessage(msg)

        response = self.receive_response()
        # Typically the server will close the session,
        # but if we get a response, it might be something like REQS.LOUT with no status.
        self.logged_in = False
        print("Logged out successfully.")

    def send_device_control(self, device_id, action):
        """
        Send a CTRL request to control a device (e.g. turn on/off).
        :param device_id: The ID of the device to control.
        :param action: One of "on", "off", "lock", "unlock", "open", "close".
        """
        if not self.logged_in:
            raise PermissionError("You must be logged in to control devices.")

        msg = csmessage.CSmessage()
        msg.setType(REQS.CTRL)
        msg.addValue("device_id", str(device_id))
        msg.addValue("action", action)
        self.pdu.sendMessage(msg)

        response = self.receive_response()
        if response is not None:
            status = response.getValue("status")
            if status == "success":
                print(f"📡 Device {device_id} action '{action}': success")
            else:
                # Could be "error" or something else
                print(f"📡 Device {device_id} action '{action}': {status}")

    def request_device_status(self, device_id):
        """
        Send a QERY request to query the status of a device.
        :param device_id: The ID of the device to query.
        """
        if not self.logged_in:
            raise PermissionError("You must be logged in to query device status.")

        msg = csmessage.CSmessage()
        msg.setType(REQS.QERY)
        msg.addValue("device_id", str(device_id))
        self.pdu.sendMessage(msg)

        response = self.receive_response()
        if response is not None:
            status = response.getValue("device_status")
            if status:
                print(f"Device {device_id} status: {status}")
            else:
                print(f"Query failed or no status returned. Raw: {response}")

    def receive_response(self):
        """
        Block until the next response arrives from the server.
        Returns a CSmessage or None on error.
        Also does some basic printing for known error cases.
        """
        try:
            response = self.pdu.recvMessage()

            # Optional: Additional checks for specific error messages:
            if response.getType() == REQS.LGIN and response.getValue("status") == "failure":
                print("Login failed: Incorrect credentials")
            elif response.getType() == REQS.CTRL and response.getValue("status") == "error":
                print(f"Device control failed: {response.getValue('error_message')}")

            return response

        except Exception as e:
            print(f"Error receiving response: {e}")
            return None
