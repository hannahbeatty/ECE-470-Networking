# test_client.py
import socket
from app_protocol import SmartHomeProtocol

def main():
    host = "localhost"
    port = 50000

    # 1) Connect to the server
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    protocol = SmartHomeProtocol(client_socket)

    print("===== TEST START =====")

    # TEST 1: Invalid login
    print("\nTest 1: Attempt login with wrong credentials...")
    protocol.send_login("admin", "wrongpass")  # Wrong password
    # The protocol's "send_login()" call prints whether the login failed.

    # TEST 2: Attempt device control while not logged in
    print("\nTest 2: Attempt device control (device_id=1, action='on') without login...")
    try:
        protocol.send_device_control(1, "on")
    except PermissionError as e:
        print(f"Expected error: {e}")

    # TEST 3: Valid login
    print("\nTest 3: Login with correct credentials...")
    protocol.send_login("admin", "password123")

    # TEST 4: Device control while logged in
    print("\nTest 4: Attempt device control (device_id=1, action='off') while logged in...")
    protocol.send_device_control(1, "off")
    # The protocol's receive_response() will tell us success or error.

    # TEST 5: Query device while logged in
    print("\nTest 5: Query device (device_id=1)...")
    protocol.request_device_status(1)
    # The protocol should print the device status or any error.

    # TEST 6: Logout
    print("\nTest 6: Logout from the system...")
    protocol.send_logout()

    # TEST 7: Attempt device control after logout
    print("\nTest 7: Attempt device control (device_id=1, action='on') after logout...")
    try:
        protocol.send_device_control(1, "on")
    except PermissionError as e:
        print(f"Expected error: {e}")

    print("\n===== TEST END =====")

    # 8) Close the socket
    client_socket.close()

if __name__ == "__main__":
    main()