# csserver.py

import socket
import logging
from csmessage import CSmessage, REQS
from cspdu import CSpdu
from home_model import SmartHouse, Room, Lamp


logging.basicConfig(level=logging.DEBUG)

class SmartHomeServer:
    """Smart Home TCP Server using request routing."""
    logger = logging.getLogger("SmartHomeServer")

    def __init__(self, host="localhost", port=50000):
        """Initialize the Smart Home Server."""
        print("[INIT] Smart Home Server is starting...")
        self.host = host
        self.port = port

        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)  # allow up to 5 clients
            self.connected = False
            print(f"[INIT] Server initialized on {self.host}:{self.port}")
        except Exception as e:
            print(f"[ERROR] Failed to initialize server: {e}")
            exit(1)

    def run(self):
        """Main server loop."""
        print(f"[RUN] Smart Home Server is running on {self.host}:{self.port}...")
        logging.info("Waiting for client connections...")

        while True:
            try:
                print("[LISTENING] Waiting for a client to connect...")
                client_socket, addr = self.server_socket.accept()
                print(f"[CONNECTED] New connection from {addr}")
                logging.info(f"Client connected: {addr}")
                self.connected = True

                # Create PDU for communication
                pdu = CSpdu(client_socket)

                # Create an instance of SmartHomeServerOps to process requests
                handler = SmartHomeServerOps()
                handler.pdu = pdu
                handler.connected = True

                # Run the request handling loop
                handler.run()

                logging.info(f"Client {addr} disconnected.")
                print(f"[DISCONNECTED] Client {addr} disconnected.")
                client_socket.close()

            except Exception as e:
                logging.error(f"[ERROR] Server error: {e}")
                print(f"[ERROR] Server error: {e}")

        print("[ERROR] The server loop has unexpectedly stopped!")
        self.server_socket.close()

class SmartHomeServerOps:
    """Handles Smart Home client requests."""
    logger = logging.getLogger("SmartHomeServerOps")

    def __init__(self):
        """Initialize Smart Home server operations."""
        print("[INIT] Smart Home Server Operations initialized.")
        self.pdu = None
        self.connected = False
        self.logged_in_user = None

        # 1) Create the house
        self.smart_home = SmartHouse(1, "Hannah's Smart Home")

        # 2) Create a room and add it to the house
        living_room = Room(room_id=101, name="Living Room")
        self.smart_home.add_room(living_room)

        # 3) Create a Lamp (device_id=0 will be overridden automatically)
        lamp = Lamp(device_id=0, on=False, shade=100)
        living_room.add_lamp(lamp)

        print(f"Created Lamp with assigned ID = {lamp.device_id}")

        # Routing table
        self._route = {
            REQS.LGIN: self._doLogin,
            REQS.LOUT: self._doLogout,
            REQS.CTRL: self._doDeviceControl,
            REQS.QERY: self._doQuery
        }

    def _doLogin(self, req: CSmessage) -> CSmessage:
        """Handles login request."""
        username = req.getValue("username")
        password = req.getValue("password")
        SmartHomeServerOps.logger.info(f"[LOGIN] Attempt from: {username}")

        if username == "admin" and password == "password123":
            self.logged_in_user = username
            resp = CSmessage(REQS.LGIN)
            resp.addValue("status", "success")
            print(f"[LOGIN SUCCESS] User: {username}")
        else:
            resp = CSmessage(REQS.LGIN)
            resp.addValue("status", "failure")
            print(f"[LOGIN FAILED] User: {username}")

        return resp

    def _doLogout(self, req: CSmessage) -> CSmessage:
        """Handles logout request."""
        print(f"[LOGOUT] User: {self.logged_in_user} logging out.")
        SmartHomeServerOps.logger.info(f"Logging out user: {self.logged_in_user}")
        self.logged_in_user = None
        self.connected = False  # terminate session
        return CSmessage(REQS.LOUT)

    def _doDeviceControl(self, req: CSmessage) -> CSmessage:
        """
        Handles device control requests. Supports:
        - Lamps / CeilingLight: "on", "off"
        - Locks: "lock", "unlock"
        - Blinds: "open", "close" (optionally "toggle" if you want)
        - Alarm: "arm", "disarm" (optionally checking codes)
        """

        if not self.logged_in_user:
            print("[ERROR] Device control attempted without login!")
            resp = CSmessage(REQS.CTRL)
            resp.addValue("status", "error")
            resp.addValue("error_message", "User not logged in")
            return resp

        # 1) Get the device_id and action from the request
        device_id_str = req.getValue("device_id")
        action = req.getValue("action")

        # Convert device_id to an integer
        try:
            device_id = int(device_id_str)
        except ValueError:
            resp = CSmessage(REQS.CTRL)
            resp.addValue("status", "error")
            resp.addValue("error_message", f"Invalid device_id: {device_id_str}")
            return resp

        # 2) Find the actual device object in the house
        found_device = None
        for room in self.smart_home.rooms.values():
            found_device = room.get_device(device_id)
            if found_device:
                break

        if not found_device:
            # No device with that ID
            resp = CSmessage(REQS.CTRL)
            resp.addValue("status", "error")
            resp.addValue("error_message", f"Device {device_id} not found in any room.")
            return resp

        # 3) Device-Specific Logic

        from home_model import Lamp, CeilingLight, Lock, Blinds, Alarm

        if isinstance(found_device, Lamp) or isinstance(found_device, CeilingLight):
            if action == "on":
                found_device.on = True
                print(f"[DEVICE CONTROL] Turned ON device {device_id} (Lamp/Light)")
            elif action == "off":
                found_device.on = False
                print(f"[DEVICE CONTROL] Turned OFF device {device_id} (Lamp/Light)")
            else:
                resp = CSmessage(REQS.CTRL)
                resp.addValue("status", "error")
                resp.addValue("error_message",
                              f"Action '{action}' not supported for Lamp/Light. Use 'on'/'off'.")
                return resp

        elif isinstance(found_device, Lock):
            if action == "lock":
                found_device.lock()
                print(f"[DEVICE CONTROL] Locked device {device_id} (Lock)")
            elif action == "unlock":
                found_device.unlock("0000")  # If you want a real code, parse it here
                print(f"[DEVICE CONTROL] Unlocked device {device_id} (Lock)")
            else:
                resp = CSmessage(REQS.CTRL)
                resp.addValue("status", "error")
                resp.addValue("error_message",
                              f"Action '{action}' not supported for Lock. Use 'lock'/'unlock'.")
                return resp

        elif isinstance(found_device, Blinds):
            if action == "open":
                found_device.is_open = True
                print(f"[DEVICE CONTROL] Blinds {device_id} opened.")
            elif action == "close":
                found_device.is_open = False
                print(f"[DEVICE CONTROL] Blinds {device_id} closed.")
            elif action == "toggle":
                found_device.toggle()
                print(f"[DEVICE CONTROL] Blinds {device_id} toggled up/down.")
            else:
                resp = CSmessage(REQS.CTRL)
                resp.addValue("status", "error")
                resp.addValue("error_message",
                              f"Action '{action}' not supported for Blinds. Use 'open', 'close', or 'toggle'.")
                return resp

        elif isinstance(found_device, Alarm):
            if action == "arm":
                found_device.arm()
                print(f"[DEVICE CONTROL] Alarm {device_id} armed.")
            elif action == "disarm":
                found_device.disarm()
                print(f"[DEVICE CONTROL] Alarm {device_id} disarmed.")
            else:
                resp = CSmessage(REQS.CTRL)
                resp.addValue("status", "error")
                resp.addValue("error_message",
                              f"Action '{action}' not supported for Alarm. Use 'arm'/'disarm'.")
                return resp

        else:
            resp = CSmessage(REQS.CTRL)
            resp.addValue("status", "error")
            resp.addValue("error_message",
                          f"Device {device_id} type is not recognized or supported by this server.")
            return resp

        resp = CSmessage(REQS.CTRL)
        resp.addValue("status", "success")
        return resp

    def _doQuery(self, req: CSmessage) -> CSmessage:
        """Handles device status queries for any known device type."""
        if not self.logged_in_user:
            print("[ERROR] Query attempted without login!")
            resp = CSmessage(REQS.QERY)
            resp.addValue("status", "error")
            resp.addValue("error_message", "User not logged in")
            return resp

        device_id_str = req.getValue("device_id")
        try:
            device_id = int(device_id_str)
        except ValueError:
            resp = CSmessage(REQS.QERY)
            resp.addValue("status", "error")
            resp.addValue("error_message", f"Invalid device_id: {device_id_str}")
            return resp

        found_device = None
        for room in self.smart_home.rooms.values():
            found_device = room.get_device(device_id)
            if found_device:
                break

        if not found_device:
            resp = CSmessage(REQS.QERY)
            resp.addValue("status", "error")
            resp.addValue("error_message", f"Device {device_id} not found")
            return resp

        dev_status = found_device.check_status()
        print(f"[QUERY] Device {device_id}: {dev_status}")
        self.logger.info(f"[QUERY] Device {device_id}: {dev_status}")

        resp = CSmessage(REQS.QERY)
        resp.addValue("status", "success")
        resp.addValue("device_status", str(dev_status))
        return resp

    def _process(self, req: CSmessage) -> CSmessage:
        """Routes requests."""
        handler = self._route.get(req.getType(), None)
        if handler:
            return handler(req)
        else:
            print(f"[WARNING] Unknown request type: {req.getType()}")
        return CSmessage(REQS.LOUT)

    def run(self):
        """Server loop."""
        print("[START] Handling client requests...")
        try:
            while self.connected:
                req = self.pdu.recvMessage()
                print(f"[REQUEST] Received: {req}")
                SmartHomeServerOps.logger.info(f"Received request: {req}")

                resp = self._process(req)
                print(f"[RESPONSE] Sending: {resp}")
                SmartHomeServerOps.logger.info(f"Sending response: {resp}")

                self.pdu.sendMessage(resp)

                if req.getType() == REQS.LOUT:
                    break
        except Exception as e:
            logging.error(f"[ERROR] Processing request: {e}")
            print(f"[ERROR] Processing request: {e}")

        self.shutdown()

    def shutdown(self):
        print("[SHUTDOWN] Closing connection...")
        self.pdu.close()
        self.connected = False


# Code for running the server
server = SmartHomeServer()  # Default host="localhost", port=50000
server.run()
