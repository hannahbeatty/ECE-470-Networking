
import csmessage
from csmessage import REQS
import cspdu

class SmartHomeProtocol:
    def __init__(self, socket_conn):
        self.pdu = cspdu.CSpdu(socket_conn)
        self.logged_in = False  # Track login state

    def send_login(self, username, password):
        msg = csmessage.CSmessage()
        msg.setType(REQS.LGIN)
        msg.addValue("username", username)
        msg.addValue("password", password)
        self.pdu.sendMessage(msg)

        response = self.receive_response()
        if response and response.getType() == REQS.LGIN and response.getValue("status") == "success":
            self.logged_in = True  # Mark as logged in

    def send_logout(self):
        if not self.logged_in:
            raise PermissionError("Must be logged in to log out")

        msg = csmessage.CSmessage()
        msg.setType(REQS.LOUT)
        self.pdu.sendMessage(msg)
        self.logged_in = False  # Reset login state

    def send_device_control(self, device_id, action):
        if not self.logged_in:
            raise PermissionError("You must be logged in to control devices")

        msg = csmessage.CSmessage()
        msg.setType(REQS.CTRL)  
        msg.addValue("device_id", str(device_id))
        msg.addValue("action", action)
        self.pdu.sendMessage(msg)

    def request_device_status(self, device_id):
        if not self.logged_in:
            raise PermissionError("You must be logged in to query device status")

        msg = csmessage.CSmessage()
        msg.setType(REQS.QERY)  
        msg.addValue("device_id", str(device_id))
        self.pdu.sendMessage(msg)

    def receive_response(self):
        try:
            response = self.pdu.recvMessage()
            if response.getType() == REQS.LGIN and response.getValue("status") == "failure":
                print("Login failed: Incorrect credentials")
            elif response.getType() == REQS.CTRL and response.getValue("status") == "error":
                print(f"Device control failed: {response.getValue('error_message')}")
            return response
        except Exception as e:
            print(f"Error receiving response: {e}")
            return None
