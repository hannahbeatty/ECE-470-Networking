'''
Created on Feb 15, 2025
@author: hannahbeatty
(forked from nigel)
'''

from enum import Enum

class REQS(Enum):
    LGIN = 100  # User Login
    LOUT = 101  # User Logout
    QERY = 104  # Get status of a device or room
    CTRL = 105  # Control a device (e.g., turn light on, unlock door)

class CSmessage:
    PJOIN = '&'
    VJOIN = '{}={}'
    VJOIN1 = '='

    def __init__(self, req_type=REQS.LGIN):
        """
        Initialize a new CSmessage with a specific request type.
        """
        self._data = {'type': req_type}

    def __str__(self) -> str:
        return self.marshal()

    def reset(self):
        """
        Reset message data.
        """
        self._data = {'type': REQS.LGIN}

    def setType(self, t):
        """
        Set the message type (e.g., LOGIN, QERY, CTRL).
        """
        if not isinstance(t, REQS):
            raise ValueError("Invalid request type")
        self._data['type'] = t

    def getType(self):
        """
        Get the message type.
        """
        return self._data['type']

    def addValue(self, key: str, value: str):
        """
        Add key-value pairs to the message.
        """
        self._data[key] = value

    def getValue(self, key: str) -> str:
        """
        Retrieve a value from the message.
        """
        return self._data.get(key, None)

    def marshal(self) -> str:
        """
        Convert message data into a serialized string for transmission.
        """
        pairs = [CSmessage.VJOIN.format(k, v) for k, v in self._data.items()]
        return CSmessage.PJOIN.join(pairs)

    def unmarshal(self, d: str):
        """
        Convert a received string into message data.
        """
        self.reset()
        if d:
            params = d.split(CSmessage.PJOIN)
            for p in params:
                if CSmessage.VJOIN1 in p:
                    k, v = p.split(CSmessage.VJOIN1)
                    self._data[k] = v

    def validate(self):
        """
        Validate that required fields are present based on request type.
        """
        req_type = self.getType()

        if req_type == REQS.LGIN and ('username' not in self._data or 'password' not in self._data):
            raise ValueError("LOGIN requires username and password")

        if req_type == REQS.QERY and 'device_id' not in self._data:
            raise ValueError("QERY requires device_id")

        if req_type == REQS.CTRL:
            if 'device_id' not in self._data or 'action' not in self._data:
                raise ValueError("CTRL requires device_id and action")
            
            valid_actions = ["on", "off", "lock", "unlock", "open", "close"]
            if self._data['action'] not in valid_actions:
                raise ValueError(f"Invalid action '{self._data['action']}'")
